package com.example.lab7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
